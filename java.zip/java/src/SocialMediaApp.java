import java.io.*;
import java.util.*;

public class SocialMediaApp {
    private static Map<String, User> users = new HashMap<>();
    private static List<Post> posts = new ArrayList<>();
    private static final String DATA_FILE = "data.ser";

    public static void main(String[] args) {
        loadData();
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("1. Register
2. Login
3. Exit");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline
            switch (choice) {
                case 1:
                    registerUser(scanner);
                    break;
                case 2:
                    loginUser(scanner);
                    break;
                case 3:
                    saveData();
                    System.exit(0);
            }
        }
    }

    private static void registerUser(Scanner scanner) {
        System.out.print("Enter username: ");
        String username = scanner.nextLine();
        System.out.print("Enter password: ");
        String password = scanner.nextLine();
        users.put(username, new User(username, password));
        System.out.println("User registered successfully.");
    }

    private static void loginUser(Scanner scanner) {
        System.out.print("Enter username: ");
        String username = scanner.nextLine();
        System.out.print("Enter password: ");
        String password = scanner.nextLine();
        User user = users.get(username);
        if (user != null && user.getPassword().equals(password)) {
            System.out.println("Login successful. Welcome " + username + "!");
            userMenu(scanner, user);
        } else {
            System.out.println("Invalid username or password.");
        }
    }

    private static void userMenu(Scanner scanner, User user) {
        while (true) {
            System.out.println("1. Post
2. Comment
3. Follow
4. View Feed
5. Logout");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline
            switch (choice) {
                case 1:
                    System.out.print("Enter your post: ");
                    String postContent = scanner.nextLine();
                    posts.add(new Post(postContent, user.getUsername()));
                    break;
                case 2:
                    System.out.print("Enter post index to comment on: ");
                    int postIndex = scanner.nextInt();
                    scanner.nextLine(); // Consume newline
                    System.out.print("Enter your comment: ");
                    String comment = scanner.nextLine();
                    if (postIndex >= 0 && postIndex < posts.size()) {
                        posts.get(postIndex).addComment(comment);
                    } else {
                        System.out.println("Invalid post index.");
                    }
                    break;
                case 3:
                    System.out.print("Enter username to follow: ");
                    String followUsername = scanner.nextLine();
                    user.follow(followUsername);
                    break;
                case 4:
                    displayFeed(user);
                    break;
                case 5:
                    return;
            }
        }
    }

    private static void displayFeed(User user) {
        System.out.println("Your Feed:");
        for (Post post : posts) {
            System.out.println(post.getAuthor() + ": " + post.getContent());
            for (String comment : post.getComments()) {
                System.out.println("  Comment: " + comment);
            }
        }
    }

    private static void loadData() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(DATA_FILE))) {
            users = (Map<String, User>) ois.readObject();
            posts = (List<Post>) ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("No previous data found, starting fresh.");
        }
    }

    private static void saveData() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(DATA_FILE))) {
            oos.writeObject(users);
            oos.writeObject(posts);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}