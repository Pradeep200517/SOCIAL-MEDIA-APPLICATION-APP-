import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Post implements Serializable {
    private String content;
    private String author;
    private List<String> comments;

    public Post(String content, String author) {
        this.content = content;
        this.author = author;
        this.comments = new ArrayList<>();
    }

    public void addComment(String comment) {
        comments.add(comment);
    }

    public String getContent() {
        return content;
    }

    public String getAuthor() {
        return author;
    }

    public List<String> getComments() {
        return comments;
    }
}