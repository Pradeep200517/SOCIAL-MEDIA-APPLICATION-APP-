import java.io.Serializable;

public class User implements Serializable {
    private String username;
    private String password;
    private String[] following;

    public User(String username, String password) {
        this.username = username;
        this.password = password;
        this.following = new String[0];
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public void follow(String username) {
        // Logic to follow another user
    }

    public void unfollow(String username) {
        // Logic to unfollow a user
    }
}