# Java-Based Social Media Application

## Overview
This is a simple console-based social media application where users can create accounts, post messages, comment, and follow other users.

## Features
- User registration and authentication
- Posting and commenting
- Follow/unfollow functionality
- Feed display for followed users

## How to Run
1. Compile the Java files in the `src` directory.
2. Run the `SocialMediaApp` class.
3. Follow the prompts to register, log in, and use the application.

## Technologies Used
- Java Collections
- File I/O for data persistence
- Multithreading to handle multiple users (not fully implemented in this basic version)